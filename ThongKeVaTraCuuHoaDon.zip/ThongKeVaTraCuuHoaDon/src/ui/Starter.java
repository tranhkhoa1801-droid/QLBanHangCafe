package ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public final class Starter {
    private Starter() {}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Dimension manHinh = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().getSize();
            JFrame cuaSo = new JFrame("Coffee Management");
            cuaSo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JTabbedPane tabs = new JTabbedPane();
            tabs.addTab("Thống kê", new ThongKeForm());
            tabs.addTab("Tra cứu hóa đơn", new TraCuuHoaDonForm());
            JPanel header = new JPanel(new BorderLayout());
            JLabel tieuDe = new JLabel("  COFFEE MANAGEMENT", SwingConstants.LEFT);
            tieuDe.setFont(new Font("Arial", Font.BOLD, 22));
            header.add(tieuDe, BorderLayout.WEST);
            JPanel noiDung = new JPanel(new BorderLayout());
            noiDung.add(header, BorderLayout.NORTH);
            noiDung.add(tabs, BorderLayout.CENTER);
            cuaSo.setContentPane(noiDung);
            cuaSo.setSize(Math.min(1440, (int) (manHinh.width * .92)), Math.min(900, (int) (manHinh.height * .88)));
            cuaSo.setLocationRelativeTo(null);
            cuaSo.setVisible(true);
        });
    }
}