package dao;

import connectDB.ConnectDB;
import dto.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TraCuuHoaDonDAO {
    public record ChiTietHoaDonTraCuu(
            HoaDon hoaDon, NhanVien nhanVien, List<ChiTietHoaDon> matHang) {}

    // tra cứu hóa đơn theo mã và thời gian
    public List<ChiTietHoaDonTraCuu> traCuuHoaDon(
            String maHoaDonCanTim, LocalDate ngayBatDau, LocalDate ngayKetThuc) {
        String tuKhoa = maHoaDonCanTim == null ? "" : maHoaDonCanTim.trim();
        if (ngayBatDau == null && ngayKetThuc == null && tuKhoa.isEmpty())
            ngayBatDau = ngayKetThuc = LocalDate.now();
        List<ChiTietHoaDonTraCuu> danhSach = new ArrayList<>();
        String sql =
                "SELECT hd.*, nv.hoTen FROM HoaDon hd JOIN NhanVien nv ON nv.maNV=hd.maNV WHERE 1=1"
                        + (tuKhoa.isEmpty() ? "" : " AND hd.maHD LIKE ?")
                        + (ngayBatDau == null ? "" : " AND hd.thoiGianTao>=?")
                        + (ngayKetThuc == null ? "" : " AND hd.thoiGianTao<?")
                        + " ORDER BY hd.thoiGianTao DESC";
        try {
            Connection con = ConnectDB.getConnection();
            synchronized (con) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    int thamSo = 1;
                    if (!tuKhoa.isEmpty()) ps.setString(thamSo++, "%" + tuKhoa + "%");
                    if (ngayBatDau != null)
                        ps.setTimestamp(thamSo++, Timestamp.valueOf(ngayBatDau.atStartOfDay()));
                    if (ngayKetThuc != null)
                        ps.setTimestamp(thamSo, Timestamp.valueOf(ngayKetThuc.plusDays(1).atStartOfDay()));
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            danhSach.add( new ChiTietHoaDonTraCuu(mapHoaDon(rs), mapNhanVien(rs), List.of()));
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return danhSach;
    }

    // xem chi tiết hóa đơn
    public ChiTietHoaDonTraCuu xemChiTietHoaDon(String maHoaDon) {
        String sql =
                "SELECT hd.*, nv.hoTen, ct.maSP AS maSP, sp.tenSP AS tenSanPham, "
                        + "ct.soLuong, ct.giaBanHienTai, ct.giaVonHienTai "
                        + "FROM HoaDon hd JOIN NhanVien nv ON nv.maNV = hd.maNV "
                        + "LEFT JOIN ChiTietHoaDon ct ON ct.maHD = hd.maHD "
                        + "LEFT JOIN SanPham sp ON sp.maSP = ct.maSP "
                        + "WHERE hd.maHD = ? ORDER BY sp.tenSP";
        try {
            Connection con = ConnectDB.getConnection();
            synchronized (con) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, maHoaDon);
                    ResultSet rs = ps.executeQuery();
                    if (!rs.next()) return null;
                    HoaDon hoaDon = mapHoaDon(rs);
                    NhanVien nhanVien = mapNhanVien(rs);
                    List<ChiTietHoaDon> matHang = new ArrayList<>();
                    do {
                        if (rs.getString("maSP") != null)
                            matHang.add(mapChiTietHoaDon(rs));
                    } while (rs.next());
                    return new ChiTietHoaDonTraCuu(hoaDon, nhanVien, matHang);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // chuyển thành HoaDon
    private HoaDon mapHoaDon(ResultSet rs) throws SQLException {
        return new HoaDon(
                rs.getString("maHD"),
                rs.getTimestamp("thoiGianTao"),
                rs.getString("ban"),
                rs.getString("maNV"),
                rs.getString("phuongThucThanhToan"),
                rs.getString("trangThai"),
                rs.getDouble("tongTien"));
    }

    // chuyển thành NhanVien
    private NhanVien mapNhanVien(ResultSet rs) throws SQLException {
        NhanVien nhanVien = new NhanVien();
        nhanVien.setHoTen(rs.getString("hoTen"));
        return nhanVien;
    }

    // chuyển thành ChiTietHoaDon
    private ChiTietHoaDon mapChiTietHoaDon(ResultSet rs) throws SQLException {
        return new ChiTietHoaDon(
                rs.getString("maHD"),
                rs.getString("maSP") + " - " + rs.getString("tenSanPham"),
                rs.getInt("soLuong"),
                rs.getDouble("giaBanHienTai"),
                rs.getDouble("giaVonHienTai"));
    }
}
