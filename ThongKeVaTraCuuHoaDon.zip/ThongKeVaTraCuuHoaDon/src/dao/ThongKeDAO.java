package dao;

import connectDB.ConnectDB;
import dto.SanPham;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ThongKeDAO {
    public record SanPhamBanChay(SanPham sanPham, int soLuongDaBan) {}

    public record DuLieuDoanhThu(double doanhThu, String moc) {}

    // tính doanh thu ngày hoặc tháng
    public double tinhDoanhThu(boolean theoThang) {
        String sql =
                "SELECT COALESCE(SUM(tongTien), 0) "
                        + "FROM HoaDon WHERE trangThai = N'Đã thanh toán' "
                        + "AND thoiGianTao >= ? AND thoiGianTao < ?";

        try {
            Connection con = ConnectDB.getConnection();
            synchronized (con) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ganKhoangThoiGian(ps, theoThang);
                    ResultSet rs = ps.executeQuery();
                    rs.next();
                    return rs.getDouble(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    // đếm số lượng hóa đơn
    public int demSoLuongDon(boolean theoThang) {
        String sql =
                "SELECT COUNT(*) FROM HoaDon "
                        + "WHERE trangThai = N'Đã thanh toán' "
                        + "AND thoiGianTao >= ? AND thoiGianTao < ?";

        try {
            Connection con = ConnectDB.getConnection();
            synchronized (con) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ganKhoangThoiGian(ps, theoThang);
                    ResultSet rs = ps.executeQuery();
                    rs.next();
                    return rs.getInt(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    // lấy danh sách sản phẩm bán chạy theo ngày hoặc tháng
    public List<SanPhamBanChay> phanTichSanPhamBanChay(boolean theoThang) {
        List<SanPhamBanChay> danhSachSanPham = new ArrayList<>();
        String sql =
                "SELECT sp.maSP, sp.tenSP, sp.giaBan, SUM(ct.soLuong) AS daBan "
                        + "FROM ChiTietHoaDon ct "
                        + "JOIN SanPham sp ON sp.maSP = ct.maSP "
                        + "JOIN HoaDon hd ON hd.maHD = ct.maHD "
                        + "WHERE hd.trangThai = N'Đã thanh toán' "
                        + "AND hd.thoiGianTao >= ? AND hd.thoiGianTao < ? "
                        + "GROUP BY sp.maSP, sp.tenSP, sp.giaBan "
                        + "ORDER BY daBan DESC";

        try {
            Connection con = ConnectDB.getConnection();
            synchronized (con) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ganKhoangThoiGian(ps, theoThang);

                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        SanPham sanPham =
                                new SanPham(
                                        rs.getString("maSP"),
                                        rs.getString("tenSP"),
                                        0,
                                        rs.getDouble("giaBan"),
                                        null);
                        danhSachSanPham.add(new SanPhamBanChay(sanPham, rs.getInt("daBan")));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return danhSachSanPham;
    }

    // lấy dữ liệu doanh thu để vẽ biểu đồ
    public List<DuLieuDoanhThu> layDuLieuDoanhThu(boolean theoThang) {
        String moc = theoThang ? "CONVERT(date, thoiGianTao)" : "DATEPART(hour, thoiGianTao)";
        String sql =
                "SELECT "
                        + moc
                        + " AS moc, SUM(tongTien) AS doanhThu "
                        + "FROM HoaDon WHERE trangThai = N'Đã thanh toán' "
                        + "AND thoiGianTao >= ? AND thoiGianTao < ? "
                        + "GROUP BY "
                        + moc
                        + " ORDER BY moc";
        List<DuLieuDoanhThu> duLieuBieuDo = new ArrayList<>();
        double[] doanhThuTheoGio = new double[24];
        double[] doanhThuTheoNgay = new double[32];

        try {
            Connection con = ConnectDB.getConnection();
            synchronized (con) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ganKhoangThoiGian(ps, theoThang);

                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        if (theoThang) {
                            int ngay = rs.getDate("moc").toLocalDate().getDayOfMonth();
                            doanhThuTheoNgay[ngay] = rs.getDouble("doanhThu");
                        } else {
                            doanhThuTheoGio[rs.getInt("moc")] = rs.getDouble("doanhThu");
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return duLieuBieuDo;
        }

        if (theoThang) {
            int soNgay = LocalDate.now().getDayOfMonth();
            for (int ngay = 1; ngay <= soNgay; ngay++) {
                duLieuBieuDo.add(
                        new DuLieuDoanhThu(doanhThuTheoNgay[ngay], String.valueOf(ngay)));
            }
        } else {
            for (int gio = 0; gio < 24; gio++) {
                duLieuBieuDo.add(
                        new DuLieuDoanhThu(doanhThuTheoGio[gio], String.format("%02d", gio)));
            }
        }

        return duLieuBieuDo;
    }

    // gắn khoảng thời gian
    private void ganKhoangThoiGian(PreparedStatement ps, boolean theoThang) throws SQLException {
        LocalDate dauKy = LocalDate.now();
        if (theoThang) dauKy = dauKy.withDayOfMonth(1);
        ps.setTimestamp(1, Timestamp.valueOf(dauKy.atStartOfDay()));
        ps.setTimestamp(2, Timestamp.valueOf(
                        (theoThang ? dauKy.plusMonths(1) : dauKy.plusDays(1)).atStartOfDay()));
    }
}
