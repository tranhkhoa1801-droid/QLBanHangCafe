package dto;

public class ChiTietHoaDon {

    private String maHD;
    private String maSP;
    private int soLuong;
    private double giaBanHienTai;
    private double giaVonHienTai;

    public ChiTietHoaDon() {
    }

    public ChiTietHoaDon(String maHD, String maSP,
            int soLuong, double giaBanHienTai,
            double giaVonHienTai) {

        this.maHD = maHD;
        this.maSP = maSP;
        this.soLuong = soLuong;
        this.giaBanHienTai = giaBanHienTai;
        this.giaVonHienTai = giaVonHienTai;
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getGiaBanHienTai() {
        return giaBanHienTai;
    }

    public void setGiaBanHienTai(double giaBanHienTai) {
        this.giaBanHienTai = giaBanHienTai;
    }

    public double getGiaVonHienTai() {
        return giaVonHienTai;
    }

    public void setGiaVonHienTai(double giaVonHienTai) {
        this.giaVonHienTai = giaVonHienTai;
    }
}
