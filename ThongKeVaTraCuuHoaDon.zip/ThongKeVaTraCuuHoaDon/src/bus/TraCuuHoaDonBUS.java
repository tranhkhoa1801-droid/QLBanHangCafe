package bus;

import java.time.LocalDate;
import java.util.List;
import dao.TraCuuHoaDonDAO;
import dao.TraCuuHoaDonDAO.ChiTietHoaDonTraCuu;

public class TraCuuHoaDonBUS {
    private final TraCuuHoaDonDAO traCuuHoaDonDAO = new TraCuuHoaDonDAO();

    public List<ChiTietHoaDonTraCuu> traCuuHoaDon(
            String maHoaDonCanTim, LocalDate ngayBatDau, LocalDate ngayKetThuc) {
        return traCuuHoaDonDAO.traCuuHoaDon(maHoaDonCanTim, ngayBatDau, ngayKetThuc);
    }

    public ChiTietHoaDonTraCuu xemChiTietHoaDon(String maHoaDon) {
        return traCuuHoaDonDAO.xemChiTietHoaDon(maHoaDon);
    }
}
