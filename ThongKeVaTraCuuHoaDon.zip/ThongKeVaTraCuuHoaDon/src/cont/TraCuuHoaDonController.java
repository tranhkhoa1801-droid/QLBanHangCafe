package cont;

import java.time.LocalDate;
import java.util.List;
import bus.TraCuuHoaDonBUS;
import dao.TraCuuHoaDonDAO.ChiTietHoaDonTraCuu;

public class TraCuuHoaDonController {
    private final TraCuuHoaDonBUS traCuuHoaDonBUS = new TraCuuHoaDonBUS();

    public List<ChiTietHoaDonTraCuu> traCuuHoaDon(
            String maHoaDonCanTim, LocalDate ngayBatDau, LocalDate ngayKetThuc) {
        return traCuuHoaDonBUS.traCuuHoaDon(maHoaDonCanTim, ngayBatDau, ngayKetThuc);
    }

    public ChiTietHoaDonTraCuu xemChiTietHoaDon(String maHoaDon) {
        return traCuuHoaDonBUS.xemChiTietHoaDon(maHoaDon);
    }
}
