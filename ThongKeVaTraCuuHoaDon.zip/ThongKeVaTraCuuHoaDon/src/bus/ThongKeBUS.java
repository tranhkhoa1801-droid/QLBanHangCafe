package bus;

import java.util.List;
import dao.ThongKeDAO;
import dao.ThongKeDAO.DuLieuDoanhThu;
import dao.ThongKeDAO.SanPhamBanChay;

public class ThongKeBUS {
    private final ThongKeDAO thongKeDAO = new ThongKeDAO();

    public double tinhDoanhThu(boolean theoThang) {
        return thongKeDAO.tinhDoanhThu(theoThang);
    }

    public int demSoLuongDon(boolean theoThang) {
        return thongKeDAO.demSoLuongDon(theoThang);
    }

    public List<SanPhamBanChay> phanTichSanPhamBanChay(boolean theoThang) {
        return thongKeDAO.phanTichSanPhamBanChay(theoThang);
    }

    public List<DuLieuDoanhThu> layDuLieuDoanhThu(boolean theoThang) {
        return thongKeDAO.layDuLieuDoanhThu(theoThang);
    }
}
