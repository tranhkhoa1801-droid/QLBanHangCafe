package connectDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class ConnectDB {
    private static final ConnectDB INSTANCE = new ConnectDB();
    private static Connection con;

    private static final String DEFAULT_URL =
            "jdbc:sqlserver://localhost:1433;databaseName=QLQuanCaPhe;encrypt=true;trustServerCertificate=true";
    private static final String DEFAULT_USER = "sa";
    private static final String DEFAULT_PASSWORD = "sapassword";

    private ConnectDB() {
    }

    public static ConnectDB getInstance() {
        return INSTANCE;
    }
    
    public synchronized void connect() throws SQLException {
        if (con != null && !con.isClosed()) {
            return;
        }

        String url = System.getProperty("qlnv.db.url", DEFAULT_URL);
        String user = System.getProperty("qlnv.db.user", DEFAULT_USER);
        String password = System.getProperty("qlnv.db.password", DEFAULT_PASSWORD);

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            throw new SQLException(
                    "Khong tim thay SQL Server JDBC Driver. Hay them sqljdbc42.jar vao Build Path.", e);
        }

        con = DriverManager.getConnection(url, user, password);
    }

    public static synchronized Connection getConnection() throws SQLException {
        if (con == null || con.isClosed()) {
            INSTANCE.connect();
        }
        return con;
    }

    public synchronized void disconnect() throws SQLException {
        if (con != null && !con.isClosed()) {
            con.close();
        }
        con = null;
    }
}
