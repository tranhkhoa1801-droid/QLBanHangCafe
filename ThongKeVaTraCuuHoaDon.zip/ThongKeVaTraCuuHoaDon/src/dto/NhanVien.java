package dto;

public class NhanVien {

    private String maNV;
    private String hoTen;
    private String vaiTro;
    private String sdt;
    private String maTK;
    private String caLamViec;
    private boolean isActive;

    public NhanVien() {
    }

    public NhanVien(String maNV, String hoTen, String vaiTro,
            String sdt, String maTK, String caLamViec,
            boolean isActive) {

        this.maNV = maNV;
        this.hoTen = hoTen;
        this.vaiTro = vaiTro;
        this.sdt = sdt;
        this.maTK = maTK;
        this.caLamViec = caLamViec;
        this.isActive = isActive;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getVaiTro() {
        return vaiTro;
    }

    public void setVaiTro(String vaiTro) {
        this.vaiTro = vaiTro;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getMaTK() {
        return maTK;
    }

    public void setMaTK(String maTK) {
        this.maTK = maTK;
    }

    public String getCaLamViec() {
        return caLamViec;
    }

    public void setCaLamViec(String caLamViec) {
        this.caLamViec = caLamViec;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }
}
