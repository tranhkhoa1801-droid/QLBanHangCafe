package cont;

import java.util.List;
import bus.ThongKeBUS;
import dao.ThongKeDAO.DuLieuDoanhThu;
import dao.ThongKeDAO.SanPhamBanChay;

public class ThongKeController {
    private final ThongKeBUS thongKeBUS = new ThongKeBUS();

    public double tinhDoanhThu(boolean theoThang) {
        return thongKeBUS.tinhDoanhThu(theoThang);
    }

    public int demSoLuongDon(boolean theoThang) {
        return thongKeBUS.demSoLuongDon(theoThang);
    }

    public List<SanPhamBanChay> phanTichSanPhamBanChay(boolean theoThang) {
        return thongKeBUS.phanTichSanPhamBanChay(theoThang);
    }

    public List<DuLieuDoanhThu> layDuLieuDoanhThu(boolean theoThang) {
        return thongKeBUS.layDuLieuDoanhThu(theoThang);
    }
}
